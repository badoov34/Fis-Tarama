--
-- PostgreSQL database dump
--

\restrict y0jAIo2nkAqibUNIr51dhP6cOjRgDddXRTa7uFcA968e30pGQMbXd05gNJW8tQt

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id character varying(36) NOT NULL,
    name character varying(100) NOT NULL,
    is_default boolean,
    created_at timestamp without time zone
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    total_amount double precision NOT NULL,
    net_amount double precision,
    vat_rate double precision,
    vat_amount double precision,
    vendor_name character varying(255),
    receipt_date date,
    receipt_number character varying(100),
    category character varying(100),
    description text,
    period_start date,
    period_end date,
    receipt_image_path character varying(500),
    vat_items_json text,
    ocr_confidence double precision,
    ocr_raw_text text,
    is_manually_edited boolean,
    is_deleted boolean,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id character varying(36) NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    company_name character varying(255),
    avatar_url character varying(500),
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, name, is_default, created_at) FROM stdin;
4df84d1c-005e-43f8-9cb5-32e6c442c4c5	market	t	2026-08-28 13:07:22.864364
f4865344-222c-4fa7-affb-11cb3f38ae78	akaryakıt	t	2026-08-28 13:07:22.864373
3bd092c5-c149-468d-801e-569b65be445d	yemek	t	2026-08-28 13:07:22.864377
1c963a8d-b937-4d0c-9419-feb5ea0299fd	ulaşım	t	2026-08-28 13:07:22.864387
0b126714-d8a6-43ad-bb6a-dfc778dfa093	kira	t	2026-08-28 13:07:22.864391
255e6810-52e6-4f33-a324-c746a462f116	personel	t	2026-08-28 13:07:22.864394
1d6c90d2-aca6-4f71-9f8d-a56ebfef7ad9	malzeme	t	2026-08-28 13:07:22.864396
7b639df6-64e7-4a5d-a360-9ed619f01ba2	faturalar	t	2026-08-28 13:07:22.864401
fab8b265-ea5b-4949-b07a-e66fe4caf8e6	telefon	t	2026-08-28 13:07:22.864404
38b06e6d-f105-442e-9fff-c172336ae5a4	internet	t	2026-08-28 13:07:22.864406
26c01eeb-6692-4c0b-8485-85b13a63e19a	bakım	t	2026-08-28 13:07:22.864408
8896127b-01f8-4525-b5f2-b896a5eb6039	temizlik	t	2026-08-28 13:07:22.86441
da8d4656-cbca-4361-bbf8-bf23149b9c69	reklam	t	2026-08-28 13:07:22.864412
80e51165-9314-44ac-af2f-d2f0ec22b7a5	sigorta	t	2026-08-28 13:07:22.864414
900afea4-c8b8-432a-b7dd-ae00b42581ec	vergi	t	2026-08-28 13:07:22.864416
aa56c9c0-52ce-4839-bddb-a4a4fd525f0f	diğer	t	2026-08-28 13:07:22.864424
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, user_id, total_amount, net_amount, vat_rate, vat_amount, vendor_name, receipt_date, receipt_number, category, description, period_start, period_end, receipt_image_path, vat_items_json, ocr_confidence, ocr_raw_text, is_manually_edited, is_deleted, deleted_at, created_at, updated_at) FROM stdin;
e29052ce-28e5-43da-9887-68624f9b9ed7	3c6f92ca-1a61-4658-8618-ad0df979ade2	2421.55	2378.92	\N	42.63	FILE MARKET MAGAZACILIK ANONIM SIRKETI	2026-08-28	ZF02026000928085	market		2026-08-21	2026-08-31	/app/uploads/6650a885-f4c4-4849-8ddd-70f7ffd037d6.jpg	[{"vat_rate": 1.0, "total_amount": 2302.55, "net_amount": 2279.75, "vat_amount": 22.8}, {"vat_rate": 20.0, "total_amount": 119.0, "net_amount": 99.17, "vat_amount": 19.83}]	\N		f	f	\N	2026-08-28 13:09:59.915877	2026-08-28 13:09:59.915878
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, name, company_name, avatar_url, password_hash, created_at, updated_at) FROM stdin;
3c6f92ca-1a61-4658-8618-ad0df979ade2	bedo@bedo.com	Bedo	Muhammed Mert		$2b$12$dXdmSJ/KG94EzKndxZ2pROPOIKUzI43ApUuz6rVmHqfc9.4HF8k8W	2026-08-28 13:09:28.766814	2026-08-28 13:09:28.766817
26f61f47-25f4-440e-86d7-505a90c92a83	test@test.com	Test	Test Firma		$2b$12$vVDPSU0yFKMzDBRZz1NCHOmeFXB8zeSTBth0.5Tv4Fl5NjqnSVVkK	2026-08-28 13:09:31.0813	2026-08-28 13:09:31.081303
\.


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: expenses expenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict y0jAIo2nkAqibUNIr51dhP6cOjRgDddXRTa7uFcA968e30pGQMbXd05gNJW8tQt

